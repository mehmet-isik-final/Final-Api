export class Kategoriler {
    katId !: string;
    katAdi !: string;
}