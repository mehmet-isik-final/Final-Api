export class Urunler {
    urunId !: string;
    urunAdi !: string;
    urunBilgi !: string;
    urunFiyat !: number;
    urunKat !: string;
    urunDeger !: number;
    urunStok !: number;
    urunResim !: string;
    urunKayit!: string;
    urunDuzenlenme !: string;
    urunSecili !: number;
    

    
}