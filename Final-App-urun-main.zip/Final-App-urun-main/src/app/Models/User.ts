export class User {
    userId !: string;
    userAdi !: string;
    userMail !: string;
    userSifre !: string;
    userAdmin !: string;
}