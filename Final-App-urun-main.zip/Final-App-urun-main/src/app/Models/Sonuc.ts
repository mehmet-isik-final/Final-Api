export class Sonuc{
    mesaj !: string;
    islem !: boolean;
}